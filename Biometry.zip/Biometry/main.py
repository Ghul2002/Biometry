import cv2
import os


sample = cv2.imread("Fingers/-", cv2.IMREAD_GRAYSCALE)

threshold_value1 = 100
threshold_value2 = 200
bestScore = 0
filename = None
image = None
kp1, kp2, mp = None, None, None

sample = cv2.Canny(sample, threshold_value1, threshold_value2)

for file in [file for file in os.listdir("ENTER FILE")]:
    fingerprintImage = cv2.imread("ENTER FILE" + file, cv2.IMREAD_GRAYSCALE)

    fingerprintImage = cv2.Canny(fingerprintImage, threshold_value1, threshold_value2)

    sift = cv2.SIFT.create()

    keypoints1, descriptors1 = sift.detectAndCompute(sample, None)
    keypoints2, descriptors2 = sift.detectAndCompute(fingerprintImage, None)

    FLANN_INDEX_KDTREE = 1
    flann = cv2.FlannBasedMatcher({'algorithm': FLANN_INDEX_KDTREE, 'trees': 10}, {})
    matches = flann.knnMatch(descriptors1, descriptors2, k=2)

    matchPoints = []

    for m, n in matches:

        if m.distance < 0.1 * n.distance:
            matchPoints.append(m)

    keypoints = 0
    if len(keypoints1) < len(keypoints2):
        keypoints = len(keypoints1)
    else:
        keypoints = len(keypoints2)

    if len(matchPoints) / keypoints * 100 > bestScore:
        bestScore = len(matchPoints) / keypoints * 100
        filename = file
        image = fingerprintImage
        kp1, kp2, mp = keypoints1, keypoints2, matchPoints

print("Matched image:" + str(filename))
print("Score:" + str(round(bestScore, 2)) + "%")

draw_params = dict(matchColor = (0,255,0),
                  singlePointColor = (0,0,255),
                  matchesMask = None,
                  flags = cv2.DrawMatchesFlags_DEFAULT)
result = cv2.drawMatches(sample, kp1, image, kp2, mp, None, **draw_params,)
result = cv2.resize(result, None, fx=3, fy=3)
cv2.imshow("Result", result)
cv2.waitKey(0)
cv2.destroyAllWindows()